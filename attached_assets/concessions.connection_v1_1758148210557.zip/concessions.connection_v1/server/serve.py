from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
from urllib.parse import unquote

# Default port can be overridden by env variable PORT
PORT = int(os.environ.get('PORT', '8080'))
ROOT = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(os.path.dirname(ROOT), 'web')
ASSETS = os.path.join(os.path.dirname(ROOT), 'assets')

SEC_HEADERS = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
}

class SPA(SimpleHTTPRequestHandler):
    # Disable directory listing completely
    def list_directory(self, path):
        self.send_error(404, "Not Found")
        return None

    def end_headers(self):
        for k, v in SEC_HEADERS.items():
            self.send_header(k, v)
        super().end_headers()

    def translate_path(self, path):
        # Serve from web/ first, then assets/; fallback to index.html
        path = path.split('?', 1)[0].split('#', 1)[0]
        path = unquote(path)
        if path == '/':
            return os.path.join(WEB, 'index.html')
        # Try web dir
        web_path = os.path.join(WEB, path.lstrip('/'))
        if os.path.isdir(web_path):
            # Prevent directory listing by always returning index for dirs
            return os.path.join(WEB, 'index.html')
        if os.path.exists(web_path):
            return web_path
        # Try assets (support both /assets/... and relative)
        if path.startswith('/assets/'):
            asset_sub = path[len('/assets/'):]
            asset_path = os.path.join(ASSETS, asset_sub)
            if os.path.exists(asset_path):
                return asset_path
        # Fallback to SPA index
        return os.path.join(WEB, 'index.html')

if __name__ == '__main__':
    os.chdir(os.path.dirname(WEB))
    with ThreadingHTTPServer(('', PORT), SPA) as httpd:
        print(f"Serving CC v1 (SPA hardened) at http://localhost:{PORT}")
        httpd.serve_forever()
